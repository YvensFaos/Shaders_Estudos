#ifndef __GL_PRINT_HELPER__
#define __GL_PRINT_HELPER__

#define PRINT_VEC(vec) printf("%f %f %f\n", vec.x, vec.y, vec.z) 

#endif